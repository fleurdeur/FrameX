TEXTEVO 2026.1.0
Text animation tool for After Effects
Documentation : https://textevo.github.io

Textevo breaks down text animations letter by letter, word by word or line by line,
with one effect to animate position, scale, rotation, opacity, blur...
Stack as many Textevo as you want on a text layer.


INSTALLATION
------------

The easiest way to install is by using the aescripts + aeplugins manager.

To install by hand :

1. In After Effects : Edit > Preferences > Scripting & Expressions
   (After Effects > Settings on macOS), check
   "Allow Scripts to Write Files and Access Network".

2. File > Scripts > Install ScriptUI Panel... and select textevo.jsxbin
   (or copy textevo.jsxbin directly into the ScriptUI Panels folder, not in a subfolder :
   Windows : C:/Program Files/Adobe/Adobe After Effects <version>/Support Files/Scripts/ScriptUI Panels/
   macOS   : /Applications/Adobe After Effects <version>/Scripts/ScriptUI Panels/ )

3. Restart After Effects and open the panel from the Window menu > textevo.jsxbin

On the first launch, Textevo asks for a folder to save its settings and presets
(Documents if you cancel). It can be changed in the settings.


UPDATING FROM AN OLDER VERSION
------------------------------

Remove the older Textevo files from the ScriptUI Panels folder, or you will have
two Textevo panels : textevo2.jsx, Textevo.jsx, textEvo241118.jsx, and on macOS
a file named "Textevo_2026.0.0\Textevo.jsx".
Your settings and presets are kept.


DOCKABLE PRESETS PANEL (OPTIONAL)
---------------------------------

The presets manager is also available as a dockable panel : "textevo presets.jsxbin",
a separate download. Install it like textevo.jsxbin. Without it, the Presets button
opens the presets manager in a floating window.


WHAT'S NEW IN 2026.1.0
------------------------

- Delay from markers (Motion window) : each letter, word or line starts at a marker
  of the layer, to sync a text with a voice over. Textevo can add the markers for you,
  at a reading speed (long words and punctuation take longer) or spread over the layer.

- The Fx button is renamed Motion. Motion on a text layer without Textevo, or with no
  text layer selected, creates a Textevo with this motion.

- Add, 2D / 3D and Paste work on all the selected text layers, or create a text layer.
  The buttons tell you what to select instead of doing nothing.

- Presets list : columns and filters by Based on and Motion.

- Based on can also set the anchor point grouping of the layer.

- Fixed : the blank panel on macOS, caused by the package of 2026.0.0.


GOOD TO KNOW
------------

- Always remove and rename a Textevo with the buttons of the panel : a Textevo is
  an effect linked to a text animator, the buttons keep both in sync.

- Effects of a preset that are not installed on your computer (third party
  effects) are skipped, with a message listing them.


Made by Wlazinski Matthieu, with the help of the community of www.motion-cafe.com
