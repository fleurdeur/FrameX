// ExtendScript side: applies a cubic-bezier (x1,y1,x2,y2) to selected keyframes.
var KE = (function () {
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function speedsFor(prop, v1, v2, dt) {
    // returns array of average speeds (one per ease dimension) or null if unsupported
    if (typeof v1 === 'number') return [(v2 - v1) / dt];
    if (!(v1 instanceof Array)) return null;
    if (prop.isSpatial) {
      var s = 0, i;
      for (i = 0; i < v1.length; i++) s += (v2[i] - v1[i]) * (v2[i] - v1[i]);
      return [Math.sqrt(s) / dt];
    }
    var out = [], j;
    for (j = 0; j < v1.length; j++) out.push((v2[j] - v1[j]) / dt);
    return out;
  }
  function easeArr(avgs, ratio, infl) {
    var a = [], i;
    for (i = 0; i < avgs.length; i++) a.push(new KeyframeEase(avgs[i] * ratio, infl));
    return a;
  }
  function applyToProp(prop, x1, y1, x2, y2) {
    var sel = prop.selectedKeys, segs = 0, i, k, ins = {}, outs = {};
    if (!sel || sel.length < 2) return 0;
    for (i = 0; i < sel.length - 1; i++) {
      var a = sel[i], b = sel[i + 1];
      var dt = prop.keyTime(b) - prop.keyTime(a);
      if (dt <= 0) continue;
      var avgs = speedsFor(prop, prop.keyValue(a), prop.keyValue(b), dt);
      if (!avgs) continue;
      var dxo = Math.max(x1, 0.001), dxi = Math.max(1 - x2, 0.001);
      outs[a] = easeArr(avgs, y1 / dxo, clamp(x1 * 100, 0.1, 100));
      ins[b] = easeArr(avgs, (1 - y2) / dxi, clamp((1 - x2) * 100, 0.1, 100));
      segs++;
    }
    for (k = 1; k <= prop.numKeys; k++) {
      if (!ins[k] && !outs[k]) continue;
      var inT = prop.keyInInterpolationType(k), outT = prop.keyOutInterpolationType(k);
      if (ins[k]) inT = KeyframeInterpolationType.BEZIER;
      if (outs[k]) outT = KeyframeInterpolationType.BEZIER;
      prop.setInterpolationTypeAtKey(k, inT, outT);
      prop.setTemporalEaseAtKey(k, ins[k] || prop.keyInTemporalEase(k), outs[k] || prop.keyOutTemporalEase(k));
    }
    return segs;
  }
  function apply(x1, y1, x2, y2) {
    try {
      var comp = app.project.activeItem;
      if (!(comp instanceof CompItem)) return 'err:Open a composition first';
      var props = comp.selectedProperties, total = 0, i;
      if (!props || !props.length) return 'err:Select keyframes first';
      app.beginUndoGroup('KeyEase: apply curve');
      for (i = 0; i < props.length; i++) {
        var p = props[i];
        if (p.propertyType !== PropertyType.PROPERTY || p.numKeys < 2) continue;
        try { total += applyToProp(p, x1, y1, x2, y2); } catch (e) { /* skip unsupported property */ }
      }
      app.endUndoGroup();
      return total ? 'ok:' + total : 'err:Select 2+ keyframes on a property';
    } catch (e2) {
      try { app.endUndoGroup(); } catch (e3) {}
      return 'err:' + e2.toString();
    }
  }
  return { apply: apply };
})();
