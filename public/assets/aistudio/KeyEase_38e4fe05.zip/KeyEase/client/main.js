(function () {
  var fs = require('fs'), path = require('path'), os = require('os');
  var DIR = path.join(os.homedir(), '.keyease');
  var CFG = path.join(DIR, 'config.json'), APPLY = path.join(DIR, 'apply.json'), STATUS = path.join(DIR, 'status.json');
  var DEFAULTS = { enabled: true, showFloatingUI: true, autoApply: false };
  var PRESETS = [['Linear', [0, 0, 1, 1]], ['Ease', [0.25, 0.1, 0.25, 1]], ['Ease In', [0.42, 0, 1, 1]], ['Ease Out', [0, 0, 0.58, 1]],
    ['Ease In-Out', [0.42, 0, 0.58, 1]], ['Snappy', [0.2, 0, 0, 1]], ['Overshoot', [0.34, 1.56, 0.64, 1]], ['Back In', [0.36, 0, 0.66, -0.56]]];
  var $ = function (id) { return document.getElementById(id); };
  var cfg = DEFAULTS, lastApplyId = null, lastResult = '';

  function readJSON(f, d) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return d; } }
  function writeJSON(f, o) { try { if (!fs.existsSync(DIR)) fs.mkdirSync(DIR); fs.writeFileSync(f, JSON.stringify(o)); } catch (e) {} }
  function setStatus(msg, cls) { var s = $('status'); s.textContent = msg; s.className = cls || ''; }

  function evalJSX(code, cb) { window.__adobe_cep__.evalScript(code, cb || function () {}); }

  function applyCurve(c) {
    if (!cfg.enabled) return;
    c = c.map(Number);
    if (c.length !== 4 || c.some(function (n) { return !isFinite(n); })) return setStatus('Invalid curve', 'err');
    evalJSX('KE.apply(' + c.join(',') + ')', function (res) {
      lastResult = String(res);
      if (lastResult.indexOf('ok:') === 0) setStatus('Applied to ' + lastResult.slice(3) + ' segment(s)', 'ok');
      else setStatus(lastResult.replace(/^err:/, ''), 'err');
    });
  }

  function parseField() {
    var v = $('vals').value.split(/[ ,]+/).filter(Boolean).map(Number);
    return v.length === 4 && v.every(isFinite) ? v : null;
  }

  var editor = new CurveEditor($('cv'), function (v, final) {
    $('vals').value = v.join(', ');
    if (final && $('auto').checked) applyCurve(v);
  });

  $('vals').addEventListener('change', function () { var v = parseField(); if (v) editor.setValues(v); });
  $('apply').addEventListener('click', function () { applyCurve(editor.getValues()); });
  $('auto').addEventListener('change', function () { cfg.autoApply = $('auto').checked; writeJSON(CFG, cfg); });

  PRESETS.forEach(function (p) {
    var b = document.createElement('button'); b.textContent = p[0];
    b.onclick = function () { editor.setValues(p[1]); $('vals').value = p[1].join(', '); if ($('auto').checked) applyCurve(p[1]); };
    $('presets').appendChild(b);
  });

  function loadConfig() {
    cfg = Object.assign({}, DEFAULTS, readJSON(CFG, {}));
    document.body.classList.toggle('disabled', !cfg.enabled);
    $('auto').checked = !!cfg.autoApply;
  }
  function checkApply() {
    var a = readJSON(APPLY, null);
    if (!a || a.id === lastApplyId) return;
    lastApplyId = a.id;
    if (Array.isArray(a.curve) && a.curve.length === 4) { editor.setValues(a.curve); $('vals').value = a.curve.join(', '); applyCurve(a.curve); }
  }

  // bridge: watch the shared folder, with polling as a safety net
  if (!fs.existsSync(DIR)) fs.mkdirSync(DIR);
  var a0 = readJSON(APPLY, null); lastApplyId = a0 ? a0.id : null; // don't replay old commands
  loadConfig();
  var t; function soon() { clearTimeout(t); t = setTimeout(function () { loadConfig(); checkApply(); }, 80); }
  try { fs.watch(DIR, soon); } catch (e) {}
  setInterval(soon, 1000);
  setInterval(function () { writeJSON(STATUS, { panelAlive: true, ts: Date.now(), lastResult: lastResult }); }, 2000);
  writeJSON(STATUS, { panelAlive: true, ts: Date.now(), lastResult: '' });
})();
