// Floating, draggable curve editor for your timeline. Needs shared/curve-editor.js loaded first.
// bridge: { getConfig, sendCurve }.  opts.onApply(curve): modify YOUR app's own keyframes with the same curve.
function createFloatingCurveWidget(host, bridge, opts) {
  opts = opts || {};
  var el = document.createElement('div');
  el.className = 'ke-float';
  el.innerHTML = '<div class="ke-bar">KeyEase <span class="ke-vals"></span></div>' +
    '<canvas width="220" height="220"></canvas><button class="ke-apply">Apply to selected keys</button>';
  host.appendChild(el);
  var bar = el.querySelector('.ke-bar'), vals = el.querySelector('.ke-vals');
  function apply(c) { if (opts.onApply) opts.onApply(c); bridge.sendCurve(c); }
  var ed = new CurveEditor(el.querySelector('canvas'), function (v, final) {
    vals.textContent = v.join(', ');
    if (final && bridge.getConfig().autoApply) apply(v);
  });
  vals.textContent = ed.getValues().join(', ');
  el.querySelector('.ke-apply').onclick = function () { apply(ed.getValues()); };
  var dx = 0, dy = 0, moving = false;
  bar.onmousedown = function (e) { moving = true; dx = e.clientX - el.offsetLeft; dy = e.clientY - el.offsetTop; };
  window.addEventListener('mousemove', function (e) { if (moving) { el.style.left = (e.clientX - dx) + 'px'; el.style.top = (e.clientY - dy) + 'px'; } });
  window.addEventListener('mouseup', function () { moving = false; });
  return { el: el, editor: ed, setVisible: function (v) { el.style.display = v ? 'block' : 'none'; } };
}
