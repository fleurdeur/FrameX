// App-side bridge (Node/Electron main or preload). Talks to the AE panel through ~/.keyease/*.json
const fs = require('fs'), path = require('path'), os = require('os');
const DIR = path.join(os.homedir(), '.keyease');
const F = { config: path.join(DIR, 'config.json'), apply: path.join(DIR, 'apply.json'), status: path.join(DIR, 'status.json') };
const DEFAULTS = { enabled: true, showFloatingUI: true, autoApply: false };
const read = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return d; } };
const write = (f, o) => { if (!fs.existsSync(DIR)) fs.mkdirSync(DIR); const t = f + '.tmp'; fs.writeFileSync(t, JSON.stringify(o)); fs.renameSync(t, f); };

const api = {
  DIR,
  getConfig: () => Object.assign({}, DEFAULTS, read(F.config, {})),
  setConfig(patch) { const c = Object.assign(api.getConfig(), patch); write(F.config, c); return c; },
  sendCurve(curve) {
    if (!api.getConfig().enabled) return false;
    write(F.apply, { id: Date.now() + '-' + Math.random().toString(36).slice(2), curve: curve.map(Number) });
    return true;
  },
  getStatus() { const s = read(F.status, null); return { connected: !!s && Date.now() - s.ts < 6000, lastResult: (s && s.lastResult) || '' }; },
  onStatus(cb, ms = 2000) { const t = setInterval(() => cb(api.getStatus()), ms); return () => clearInterval(t); },
};
module.exports = api;
