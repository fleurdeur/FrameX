# KeyEase (After Effects CEP panel + app bridge)

## Install (dev)
1. Copy this folder to the CEP extensions dir:
   - Windows: `C:\Program Files (x86)\Common Files\Adobe\CEP\extensions\KeyEase`
   - macOS: `/Library/Application Support/Adobe/CEP/extensions/KeyEase`
2. Allow unsigned panels (dev only):
   - Windows: `reg add HKCU\Software\Adobe\CSXS.9 /v PlayerDebugMode /t REG_SZ /d 1 /f` (repeat for CSXS.10, .11, ...)
   - macOS: `defaults write com.adobe.CSXS.9 PlayerDebugMode 1` (repeat for 10, 11, ...)
3. After Effects: Edit > Preferences > Scripting & Expressions > Allow Scripts to Write Files and Access Network.
4. Restart AE, open Window > Extensions > KeyEase.

To ship: sign and package as .zxp with Adobe's ZXPSignCmd, and your app's installer can place it for users.

## Bridge protocol (folder `~/.keyease/`)
- `config.json`  app -> panel: `{enabled, showFloatingUI, autoApply}`. `enabled:false` greys out the panel.
- `apply.json`   app -> panel: `{id, curve:[x1,y1,x2,y2]}`. A new `id` makes the panel apply to selected AE keys.
- `status.json`  panel -> app: `{panelAlive, ts, lastResult}`. Connected if `ts` is < 6s old.

## App side
`app-side/keyease-bridge.js` (Node/Electron), `floating-widget.js` + `../shared/curve-editor.js` (UI), `demo.html` (settings toggles + floating widget in a mock timeline). Use `onApply` to edit your own app's keyframes with the same curve.
