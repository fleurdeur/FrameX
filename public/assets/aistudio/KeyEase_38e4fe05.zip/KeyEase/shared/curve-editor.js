// Cubic-bezier curve editor (canvas). Shared by the AE panel and the app's floating widget.
(function (root) {
  function CurveEditor(canvas, onChange) {
    var ctx = canvas.getContext('2d');
    var W = canvas.width, H = canvas.height, PAD = 26, YMIN = -0.6, YMAX = 1.6;
    var P = [0.25, 0.1, 0.25, 1], drag = -1;
    function tx(x) { return PAD + x * (W - 2 * PAD); }
    function ty(y) { return H - PAD - (y - YMIN) / (YMAX - YMIN) * (H - 2 * PAD); }
    function fx(px) { return (px - PAD) / (W - 2 * PAD); }
    function fy(py) { return YMIN + (H - PAD - py) / (H - 2 * PAD) * (YMAX - YMIN); }
    function r2(v) { return Math.round(v * 100) / 100; }
    function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
    function draw() {
      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = '#1b1b1f'; ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = '#3a3a42'; ctx.lineWidth = 1;
      ctx.strokeRect(tx(0), ty(1), tx(1) - tx(0), ty(0) - ty(1));
      ctx.setLineDash([4, 4]); ctx.beginPath(); ctx.moveTo(tx(0), ty(0)); ctx.lineTo(tx(1), ty(1)); ctx.stroke(); ctx.setLineDash([]);
      ctx.strokeStyle = '#8a8a99';
      ctx.beginPath(); ctx.moveTo(tx(0), ty(0)); ctx.lineTo(tx(P[0]), ty(P[1]));
      ctx.moveTo(tx(1), ty(1)); ctx.lineTo(tx(P[2]), ty(P[3])); ctx.stroke();
      ctx.strokeStyle = '#ff7a3d'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(tx(0), ty(0));
      ctx.bezierCurveTo(tx(P[0]), ty(P[1]), tx(P[2]), ty(P[3]), tx(1), ty(1)); ctx.stroke();
      ctx.fillStyle = '#ffd2bd';
      for (var i = 0; i < 2; i++) { ctx.beginPath(); ctx.arc(tx(P[2 * i]), ty(P[2 * i + 1]), 6, 0, 6.2832); ctx.fill(); }
    }
    function pos(e) { var r = canvas.getBoundingClientRect(); return [(e.clientX - r.left) * W / r.width, (e.clientY - r.top) * H / r.height]; }
    canvas.addEventListener('mousedown', function (e) {
      var p = pos(e), best = 16, i;
      drag = -1;
      for (i = 0; i < 2; i++) {
        var d = Math.sqrt(Math.pow(p[0] - tx(P[2 * i]), 2) + Math.pow(p[1] - ty(P[2 * i + 1]), 2));
        if (d < best) { best = d; drag = i; }
      }
    });
    window.addEventListener('mousemove', function (e) {
      if (drag < 0) return;
      var p = pos(e);
      P[2 * drag] = r2(clamp(fx(p[0]), 0, 1));
      P[2 * drag + 1] = r2(clamp(fy(p[1]), YMIN, YMAX));
      draw(); if (onChange) onChange(P.slice(), false);
    });
    window.addEventListener('mouseup', function () {
      if (drag < 0) return; drag = -1; if (onChange) onChange(P.slice(), true);
    });
    this.setValues = function (v) { P = [clamp(+v[0], 0, 1), +v[1], clamp(+v[2], 0, 1), +v[3]]; draw(); };
    this.getValues = function () { return P.slice(); };
    draw();
  }
  root.CurveEditor = CurveEditor;
})(typeof window !== 'undefined' ? window : this);
